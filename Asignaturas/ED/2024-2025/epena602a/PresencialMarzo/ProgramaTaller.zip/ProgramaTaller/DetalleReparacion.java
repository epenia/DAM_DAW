public class DetalleReparacion {
	private Object _numeroFactura;
	private Object _idReparacion;
	private Object _coste;
	private Object _duracion;
	public Factura _tiene;

	public void getNumeroFactura() {
		return this._numeroFactura;
	}

	public void setNumeroFactura(Object aNumeroFactura) {
		this._numeroFactura = aNumeroFactura;
	}

	public void getIdReparacion() {
		return this._idReparacion;
	}

	public void setIdReparacion(Object aIdReparacion) {
		this._idReparacion = aIdReparacion;
	}

	public void getCoste() {
		return this._coste;
	}

	public void setCoste(Object aCoste) {
		this._coste = aCoste;
	}

	public void getDuracion() {
		return this._duracion;
	}

	public void setDuracion(Object aDuracion) {
		this._duracion = aDuracion;
	}
}