import java.util.ArrayList;

public class Cliente {
	private String _dni;
	private String _nombre;
	private String _telefono;
	private String _apellidos;
	private String _direccion;
	private String _email;
	public ArrayList<Vehiculo> _tiene = new ArrayList<Vehiculo>();

	public String getDni() {
		return this._dni;
	}

	public void setDni(String aDni) {
		this._dni = aDni;
	}

	public String getNombre() {
		return this._nombre;
	}

	public void setNombre(String aNombre) {
		this._nombre = aNombre;
	}

	public String getTelefono() {
		return this._telefono;
	}

	public void setTelefono(String aTelefono) {
		this._telefono = aTelefono;
	}

	public String getApellidos() {
		return this._apellidos;
	}

	public void setApellidos(String aApellidos) {
		this._apellidos = aApellidos;
	}

	public String getDireccion() {
		return this._direccion;
	}

	public void setDireccion(String aDireccion) {
		this._direccion = aDireccion;
	}

	public String getEmail() {
		return this._email;
	}

	public void setEmail(String aEmail) {
		this._email = aEmail;
	}

	public void cambiarTelefono(String aTelefono) {
		throw new UnsupportedOperationException();
	}

	public Cliente() {
		throw new UnsupportedOperationException();
	}

	public Cliente(String aDni, String aNombre, String aApellidos, String aDireccion, String aEmail) {
		throw new UnsupportedOperationException();
	}
}