public class Trabajador {
}