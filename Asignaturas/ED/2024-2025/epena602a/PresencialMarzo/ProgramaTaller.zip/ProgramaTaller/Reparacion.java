import java.util.ArrayList;

public class Reparacion {
	private int _idReparacion;
	private float _coste;
	private String _descripcion;
	private int _duracion;
	public ArrayList<DetalleReparacion> _tiene = new ArrayList<DetalleReparacion>();

	public int getIdReparacion() {
		return this._idReparacion;
	}

	public void setIdReparacion(int aIdReparacion) {
		this._idReparacion = aIdReparacion;
	}

	public float getCoste() {
		return this._coste;
	}

	public void setCoste(float aCoste) {
		this._coste = aCoste;
	}

	public String getDescripcion() {
		return this._descripcion;
	}

	public void setDescripcion(String aDescripcion) {
		this._descripcion = aDescripcion;
	}

	public int getDuracion() {
		return this._duracion;
	}

	public void setDuracion(int aDuracion) {
		this._duracion = aDuracion;
	}
}