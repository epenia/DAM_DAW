public class Vehiculo {
	private String _matricula;
	private String _marca;
	private String _modelo;
	private String _matriculacion;
	public Cliente _tiene;

	public String getMatricula() {
		return this._matricula;
	}

	public void setMatricula(String aMatricula) {
		this._matricula = aMatricula;
	}

	public String getMarca() {
		return this._marca;
	}

	public void setMarca(String aMarca) {
		this._marca = aMarca;
	}

	public String getModelo() {
		return this._modelo;
	}

	public void setModelo(String aModelo) {
		this._modelo = aModelo;
	}

	public String getMatriculacion() {
		return this._matriculacion;
	}

	public void setMatriculacion(String aMatriculacion) {
		this._matriculacion = aMatriculacion;
	}
}