public class Factura {
	private String _numeroFactura;
	private String _fechaFactura;
	private boolean _pagada;
	private float _importe;
	private String _detalle;
	public Cliente _tiene;

	public String getNumeroFactura() {
		return this._numeroFactura;
	}

	public void setNumeroFactura(String aNumeroFactura) {
		this._numeroFactura = aNumeroFactura;
	}

	public String getFechaFactura() {
		return this._fechaFactura;
	}

	public void setFechaFactura(String aFechaFactura) {
		this._fechaFactura = aFechaFactura;
	}

	public boolean getPagada() {
		return this._pagada;
	}

	public void setPagada(boolean aPagada) {
		this._pagada = aPagada;
	}

	public float getImporte() {
		return this._importe;
	}

	public void setImporte(float aImporte) {
		this._importe = aImporte;
	}

	public String getDetalle() {
		return this._detalle;
	}

	public void setDetalle(String aDetalle) {
		this._detalle = aDetalle;
	}
}