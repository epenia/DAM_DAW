public class Escuderia {

	private int nombre;
	private int paisOrigen;
	private int presupuesto;

	public void agregarPiloto() {
		// TODO - implement Escuderia.agregarPiloto
		throw new UnsupportedOperationException();
	}

	public void eliminarPiloto() {
		// TODO - implement Escuderia.eliminarPiloto
		throw new UnsupportedOperationException();
	}

}