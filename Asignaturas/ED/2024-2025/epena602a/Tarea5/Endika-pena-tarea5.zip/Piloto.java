public class Piloto {

	private int nombre;
	private int edad;
	private int nacionalidad;
	private int numCoche;

	public void asignarCoche() {
		// TODO - implement Piloto.asignarCoche
		throw new UnsupportedOperationException();
	}

	public void obtenerDetalles() {
		// TODO - implement Piloto.obtenerDetalles
		throw new UnsupportedOperationException();
	}

}