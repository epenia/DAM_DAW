public class Coche {

	private int modelo;
	private int motor;
	private int velMax;

	public void iniciar() {
		// TODO - implement Coche.iniciar
		throw new UnsupportedOperationException();
	}

	public void detener() {
		// TODO - implement Coche.detener
		throw new UnsupportedOperationException();
	}

}