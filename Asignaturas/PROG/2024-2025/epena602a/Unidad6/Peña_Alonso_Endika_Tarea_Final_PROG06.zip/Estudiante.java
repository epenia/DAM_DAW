import java.util.Scanner;

class Estudiante {
	private String dni;
	private String nombre;
	private double[] notasExamen;
	private double[] notasTarea;
	private int indiceExamen;
	private int indiceTarea;

	Estudiante(String dni, String nombre) {
		this.dni = dni;
		this.nombre = nombre;
		this.notasExamen = new double[10];
		this.notasTarea = new double[10];
		this.indiceExamen = 0;
		this.indiceTarea = 0;
	}

	public String getDni() {
		return dni;
	}

	public void añadirNotaExamen(double nota) {
		if (indiceExamen >= 10) {
			System.out.println("No se pueden añadir más notas de examen.");
            System.out.println("");
			return;
		}

		notasExamen[indiceExamen++] = nota;
	}

	public void añadirNotaTarea(double nota) {
		if (indiceTarea >= 10) {
			System.out.println("No se pueden añadir más notas de tarea.");
            System.out.println("");
			return;
		}
		
		notasTarea[indiceTarea++] = nota;
	}

	public double calcularMediaExamenes() {
		if (indiceExamen == 0)
			return 0;
		
		double suma = 0;		
		for (int i = 0; i < indiceExamen; i++) {
			suma += notasExamen[i];
		}
		
		return suma / indiceExamen;
	}

	public double calcularMediaTareas() {
		if (indiceTarea == 0)
			return 0;
		
		double suma = 0;
		for (int i = 0; i < indiceTarea; i++) {
			suma += notasTarea[i];
		}
		
		return suma / indiceTarea;
	}

	public double calcularNotaMedia() {
		return Math.round((calcularMediaExamenes() * 0.75) + (calcularMediaTareas() * 0.25));
	}

	@Override
	public String toString() {
		return "DNI: " + dni + ", Nombre: " + nombre + ", Media Exámenes: " + calcularMediaExamenes()
				+ ", Media Tareas: " + calcularMediaTareas() + ", Nota Final: " + calcularNotaMedia();
	}
}
