import java.util.Scanner;

public class principal {
	private static Estudiante[] estudiantes = new Estudiante[30];
    private static int totalEstudiantes = 0;
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int opcion;
        
        do {
            System.out.println("\nMenú:");
            System.out.println("");
            System.out.println("1. Crear estudiante");
            System.out.println("2. Introducir nota a un estudiante");
            System.out.println("3. Mostrar resumen de estudiantes");
            System.out.println("4. Calcular media de la clase");
            System.out.println("5. Salir");
            System.out.println("");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    crearEstudiante();
                    break;
                case 2:
                    introducirNota();
                    break;
                case 3:
                    mostrarResumen();
                    break;
                case 4:
                    calcularMediaClase();
                    break;
                case 5:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
            
        } while (opcion != 5);
    }

    private static void crearEstudiante() {
        if (totalEstudiantes >= 30) {
            System.out.println("No se pueden agregar más estudiantes.");
            return;
        }
        
        System.out.print("Ingrese el DNI del estudiante: ");
        String dni = scanner.nextLine();
        System.out.print("Ingrese el nombre del estudiante: ");
        String nombre = scanner.nextLine();
        

        Estudiante estudiante = buscarEstudiante(dni);
        if (estudiante != null) {
            System.out.println("El estudiante ya existe.");
        	return;
        }
        
        estudiantes[totalEstudiantes++] = new Estudiante(dni, nombre);
        System.out.println("Estudiante agregado exitosamente.");
        System.out.println("");
    }

    private static void introducirNota() {
        System.out.print("Ingrese el DNI del estudiante: ");
        String dni = scanner.nextLine();
        
        Estudiante estudiante = buscarEstudiante(dni);
        
        if (estudiante == null) {
            System.out.println("Estudiante no encontrado.");
            System.out.println("");
            return;
        }
        
        System.out.print("Ingrese el tipo de nota (1: Examen, 2: Tarea): ");
        int tipo = scanner.nextInt();
        System.out.print("Ingrese la nota (0-10): ");
        double nota = scanner.nextDouble();
        
        if (nota < 0 || nota > 10) {
            System.out.println("Nota inválida.");
            System.out.println("");
            return;
        }
        
        switch (tipo) {
	        case 1:
	            estudiante.añadirNotaExamen(nota);
	        	break;
	        case 2:
	            estudiante.añadirNotaTarea(nota);
	        	break;
	        default:
	            System.out.println("Opción inválida.");
	            System.out.println("");
	            break;	        	
        }
    }

    private static void mostrarResumen() {
        if (totalEstudiantes == 0) {
            System.out.println("No hay estudiantes registrados.");
            System.out.println("");
            return;
        }
        
        for (int i = 0; i < totalEstudiantes; i++) {
            System.out.println(estudiantes[i]);
        }
    }

    private static void calcularMediaClase() {
        if (totalEstudiantes == 0) {
            System.out.println("No hay estudiantes registrados.");
            System.out.println("");
            return;
        }
        double suma = 0;
        for (int i = 0; i < totalEstudiantes; i++) {
            suma += estudiantes[i].calcularNotaMedia();
        }
        System.out.println("Media de la clase: " + (suma / totalEstudiantes));
        System.out.println("");
    }

    private static Estudiante buscarEstudiante(String dni) {
        for (int i = 0; i < totalEstudiantes; i++) {
            if (estudiantes[i].getDni().equals(dni)) {
                return estudiantes[i];
            }
        }
        return null;
    }

}

