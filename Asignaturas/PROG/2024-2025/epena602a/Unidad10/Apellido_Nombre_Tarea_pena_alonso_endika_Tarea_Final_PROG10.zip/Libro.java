import java.io.Serializable;

public class Libro implements Serializable {
    private String isbn;
    private String titulo;
    private String autor;
    private String genero;
    private int numPaginas;
    private int vecesLeido;

    public Libro(String isbn, String titulo, String autor, String genero, int numPaginas) {
        this.isbn = isbn;
        this.titulo = titulo;
        this.autor = autor;
        this.genero = genero;
        this.numPaginas = numPaginas;
        this.vecesLeido = 0;
    }

    // Getters y setters
    public String getIsbn() {
        return this.isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getTitulo() {
        return this.titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return this.autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getGenero() {
        return this.genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public int getNumPaginas() {
        return this.numPaginas;
    }

    public void setNumPaginas(int numPaginas) {
        this.numPaginas = numPaginas;
    }

    public int getVecesLeido() {
        return this.vecesLeido;
    }

    public void setVecesLeido(int vecesLeido) {
        this.vecesLeido = vecesLeido;
    }

    public void incrementarVecesLeido() {
        this.vecesLeido++;
    }

    @Override
    public String toString() {
        return titulo + " - " + autor + " (" + genero + "), " + numPaginas + " paginas, leído " + vecesLeido + " veces" ;
    }
}
