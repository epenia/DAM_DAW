import java.io.*;
import java.util.ArrayList;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import java.util.Comparator;
import java.util.Random;
import java.util.Collections;

public class principal {
	private static final String FILE_PATH = "src/libros.txt";
	private static ArrayList<Libro> libros = new ArrayList<Libro>();
	private static JFrame frame = new JFrame("Mi biblioteca");
	private static JTextArea ta = new JTextArea();

	public static void main(String[] args) {
		// Creating the Frame
		cargarFichero();

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(800, 600);

		ta.setText("Bienvenido al sistema de gestión de libros.");
		// Agregar un WindowListener para capturar el evento de cierre
		frame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				// Mostrar un cuadro de diálogo de confirmación
				int opcion = JOptionPane.showConfirmDialog(frame, "¿Estás seguro de que deseas salir?",
						"Confirmar salida", JOptionPane.YES_NO_OPTION);

				if (opcion == JOptionPane.YES_OPTION) {
					// Guardar los libros en el archivo antes de cerrar
					guardarLibrosEnFichero();
					System.exit(0); // Cerrar la aplicación
				}
			}
		});

		// Adding Components to the frame.
		frame.getContentPane().add(BorderLayout.NORTH, principal.mostrarMenu());
		frame.getContentPane().add(BorderLayout.CENTER, ta);
		frame.setVisible(true);

	}

	private static JMenuBar mostrarMenu() {
		// Creating the MenuBar and adding components
		JMenuBar mb = new JMenuBar();
		JMenu m1 = new JMenu("Menú");
		mb.add(m1);
		JMenuItem nuevoLibro = new JMenuItem("Nuevo libro");
		JMenuItem leerLibro = new JMenuItem("Leer libro");
		JMenuItem eliminarLibro = new JMenuItem("Eliminar libro");
		JMenuItem mostrarLibros = new JMenuItem("Mostrar libros");
		JMenuItem mostrarLibrosLeidos = new JMenuItem("Libros más leidos");
		JMenuItem salir = new JMenuItem("Salir");

		m1.add(nuevoLibro);
		m1.add(leerLibro);
		m1.add(eliminarLibro);
		m1.add(mostrarLibros);
		m1.add(mostrarLibrosLeidos);
		m1.add(salir);

		nuevoLibro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String isbn;
				do {
					isbn = JOptionPane.showInputDialog(frame, "Introduce el isbn");
				} while (isbn == null || isbn.isEmpty());
				
				if (isExistISBN(isbn)) {
					JOptionPane.showMessageDialog(frame, "El isbn no se puede repetir");
					return;
				}
				

				String titulo;
				do {
					titulo = JOptionPane.showInputDialog(frame, "Introduce el titulo");
				} while (titulo == null ||titulo.isEmpty());

				String autor;
				do {
					autor = JOptionPane.showInputDialog(frame, "Introduce el autor");
				} while (autor == null ||autor.isEmpty());

				String genero;
				do {
					genero = JOptionPane.showInputDialog(frame, "Introduce el género");
				} while (genero == null || genero.isEmpty());

				int nPaginas = 0;
				do {
					String paginas = JOptionPane.showInputDialog(frame, "Introduce el número de páginas");
					try {
						// Convertir la entrada a un número entero
						nPaginas = Integer.parseInt(paginas);
					} catch (NumberFormatException exception) {

					}
				} while (nPaginas <= 0);

				Libro nuevoLibro = new Libro(isbn, titulo, autor, genero, nPaginas);
				libros.add(nuevoLibro);

				JOptionPane.showMessageDialog(frame, "El libro ha sido añadido correctamente");
				mostrarLibros();
			}
		});

		leerLibro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int Option = JOptionPane.showConfirmDialog(frame, "¿Desea leer un libro de forma aleatoria?");
				
				System.out.println(Option);
				
				if (Option == 0) {
			        Random rand = new Random();
			        int indiceAleatorio = rand.nextInt(libros.size());
					libros.get(indiceAleatorio).incrementarVecesLeido();
					JOptionPane.showMessageDialog(frame, libros.get(indiceAleatorio).toString());
					
					return;
				}

				
				mostrarLibros();
				
				int indice = 0;
				do {
					String indiceString = JOptionPane.showInputDialog(frame, "Introduce el numero del libro que deseas leer");
					try {
						// Convertir la entrada a un número entero
						indice = Integer.parseInt(indiceString);
					} catch (NumberFormatException exception) {

					}
				} while (indice <= 0);

				int indiceSeleccionado = indice - 1;

				try {
					libros.get(indiceSeleccionado).incrementarVecesLeido();
					JOptionPane.showMessageDialog(frame, libros.get(indiceSeleccionado).toString());
				} catch (Exception readException) {
					JOptionPane.showMessageDialog(frame, "No se ha encontrado el libro seleccionado");
				}

				mostrarLibros();
			}
		});

		eliminarLibro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int indice = 0;
				do {
					String indiceString = JOptionPane.showInputDialog("Introduce el numero del libro que deseas leer");
					try {
						indice = Integer.parseInt(indiceString);
					} catch (NumberFormatException exception) {
					}
				} while (indice <= 0);

				int indiceSeleccionado = indice - 1;

				try {
					libros.remove(indiceSeleccionado);
					JOptionPane.showMessageDialog(frame, "Libro eliminado correctamente");
				} catch (Exception readException) {
					JOptionPane.showMessageDialog(frame, "No se ha encontrado el libro seleccionado");
				}
				
				mostrarLibros();
			}
		});

		mostrarLibros.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mostrarLibros();
			}
		});

		mostrarLibrosLeidos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mostrarLibrosLeidos();
			}
		});

		salir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("Seleccionado Salir'");
				guardarLibrosEnFichero();
				System.exit(0); // Cierra la aplicación
			}
		});

		return mb;
	}

	private static void cargarFichero() {
		try (ObjectInputStream leerArchivo = new ObjectInputStream(new FileInputStream(FILE_PATH))) {
			libros.clear(); // Limpiar la lista antes de cargar nuevos datos
			ArrayList<Libro> librosLeidos = (ArrayList<Libro>) leerArchivo.readObject();
			libros.addAll(librosLeidos);
			System.out.println("Libros cargados correctamente.");
		} catch (FileNotFoundException e) {
			System.out.println("No se encontró el archivo. Se creará uno nuevo al guardar.");
		} catch (IOException | ClassNotFoundException e) {
			System.out.println("Error al leer el archivo: " + e.getMessage());
		}
	}

	private static void guardarLibrosEnFichero() {
		try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(FILE_PATH))) {
			outputStream.writeObject(libros);
			System.out.println("Libros guardados correctamente.");
		} catch (IOException e) {
			System.out.println("Error al guardar el archivo: " + e.getMessage());
		}
	}

	private static void mostrarLibros() {
		ta.setText("Listado de libros: \n");

		for (int i = 0; i < libros.size(); i++) {
			int numeroIndice = i + 1;
			Libro libroMostrado = libros.get(i);
			ta.append(numeroIndice + ": " + libroMostrado.toString() + "\n");
		}
	}

	private static void mostrarLibrosLeidos() {
		ta.setText("Listado de libros leídos: \n");
		libros.sort(Comparator.comparingInt(Libro::getVecesLeido).reversed());
		for (Libro libro : libros) {
			if (libro.getVecesLeido() > 0) {
				ta.append("Libro: " + libro.toString() + "\n");
			}
		}
	}
	
	private static boolean isExistISBN(String isbn) {
		for (Libro libro : libros) {
			if (libro.getIsbn().equals(isbn)) {
				return true;
			}
		}
		return false;
	}
}
