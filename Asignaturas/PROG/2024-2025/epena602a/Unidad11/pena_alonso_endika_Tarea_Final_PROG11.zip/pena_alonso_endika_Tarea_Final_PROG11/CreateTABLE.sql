CREATE TABLE juegos (
  juego_id INT PRIMARY KEY AUTO_INCREMENT,
  Titulo VARCHAR(100),
  Plataforma VARCHAR(50),
  anio_lanzamiento INT,
  Compañía VARCHAR(100),
  horas_jugadas INT
);