import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.Scanner;

public class principal2 {
    private static final String FILE_PATH = "src/canciones.txt";
    private static ArrayList<String> canciones = new ArrayList<>();
    private static Scanner input = new Scanner(System.in);

    public static void main(String[] args) {
        String menuOption;
        do {
            mostrarMenu();
            menuOption = input.nextLine().toLowerCase();
            switch (menuOption) {
                case "a":
                    leerFichero();
                    break;
                case "b":
                    agregarCancion();
                    break;
                case "c":
                    eliminarCancion();
                    break;
                case "d":
                	mostrarCancionesAleatorias();
                    break;
                case "e":
                    mostrarTodasCanciones();
                    break;
                case "f":
                    guardarCancionesEnFichero();
                    break;
                case "g":
                    System.out.println("Saliendo del programa");
                    break;
                default:
                    System.out.println("Opción de menú no encontrada");
                    break;
            }
        } while (!menuOption.equals("g"));
        input.close();
    }

    private static void mostrarMenu() {
        System.out.println("\nMenú de opciones:");
        System.out.println("a: Leer canciones del fichero");
        System.out.println("b: Añadir una nueva canción");
        System.out.println("c: Eliminar una canción existente");
        System.out.println("d: Mostrar una canción aleatoria");
        System.out.println("e: Mostrar todas las canciones almacenadas");
        System.out.println("f: Guardar todas las canciones en el fichero");
		System.out.println("");
        System.out.println("g: Salir del programa");
		System.out.println("");
        System.out.print("Seleccione una opción: ");
    }

    private static void leerFichero() {
        if (!canciones.isEmpty()) {
            System.out.println("Ya existen canciones previamente. ¿Quiere continuar cargándolas?");
            System.out.print("(si, no): ");
            String recargarFichero = input.nextLine().toLowerCase();
            if (!recargarFichero.equals("si")) {
                return;
            }
            canciones.clear();
        }
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_PATH))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                canciones.add(linea);
            }
            System.out.println("Las canciones han sido cargadas.");
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
    }

    private static void agregarCancion() {
        System.out.print("Introduce una canción: ");
        String cancion;
        while (true) {
            cancion = input.nextLine();
            if (!cancion.isEmpty()) {
                canciones.add(cancion);
                System.out.println("Canción añadida.");
                break;
            } else {
                System.out.println("La canción nueva no puede estar vacía. Inténtelo de nuevo:");
            }
        }
    }

    private static void eliminarCancion() {
        if (canciones.isEmpty()) {
            System.out.println("No se han encontrado canciones.");
            return;
        }
        mostrarTodasCanciones();
        System.out.print("Seleccione el número de la canción que quiere eliminar (0 para cancelar): ");
        int indice;
        try {
            indice = input.nextInt();
            input.nextLine(); // Consumir el salto de línea pendiente
            if (indice == 0) {
                System.out.println("Cancelando la operación.");
                return;
            }
            if (indice > 0 && indice <= canciones.size()) {
                canciones.remove(indice - 1);
                System.out.println("Canción eliminada.");
            } else {
                System.out.println("Número fuera de rango. Operación cancelada.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Entrada inválida. Operación cancelada.");
            input.nextLine(); // Limpiar el buffer del scanner
        }
    }

    private static void mostrarCancionesAleatorias() {
        if (canciones.isEmpty()) {
            System.out.println("No se han encontrado canciones.");
            return;
        }
        Collections.shuffle(canciones);
        System.out.println("Canciones en orden aleatorio:");
        for (String cancion : canciones) {
            System.out.println(cancion);
        }
    }

    private static void mostrarTodasCanciones() {
        if (canciones.isEmpty()) {
            System.out.println("No se han encontrado canciones.");
            return;
        }
        System.out.println("\nListado de canciones:");
        for (int i = 0; i < canciones.size(); i++) {
            System.out.println((i + 1) + ": " + canciones.get(i));
        }
    }

    private static void guardarCancionesEnFichero() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_PATH, false))) {
            for (String cancion : canciones) {
                bw.write(cancion);
                bw.newLine();
            }
            System.out.println("Canciones almacenadas en el fichero.");
        } catch (IOException e) {
            System.out.println("Error al escribir en el archivo: " + e.getMessage());
        }
    }
}
