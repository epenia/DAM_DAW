class Moto extends Vehiculo {
    private int cilindrada;

    public Moto(String matricula, String marca, String modelo, int anioFabricacion, double kilometraje, int cilindrada) {
        super(matricula, marca, modelo, anioFabricacion, kilometraje);
        this.cilindrada = cilindrada;
    }

    public double calcularCostoMantenimiento() {
        if (cilindrada < 250) {
            return (kilometraje * 0.03) + 50;
        } else {
            return (kilometraje * 0.05) + 80;
        }
    }
}