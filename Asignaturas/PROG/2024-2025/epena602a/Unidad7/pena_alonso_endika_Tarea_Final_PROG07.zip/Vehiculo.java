abstract class Vehiculo implements Mantenible {
    protected String matricula;
    protected String marca;
    protected String modelo;
    protected int anioFabricacion;
    protected double kilometraje;

    public Vehiculo(String matricula, String marca, String modelo, int anioFabricacion, double kilometraje) {
        this.matricula = matricula;
        this.marca = marca;
        this.modelo = modelo;
        this.anioFabricacion = anioFabricacion;
        this.kilometraje = kilometraje;
    }

    public abstract double calcularCostoMantenimiento();

    public void mostrarInformacion() {
        System.out.println("Matrícula: " + matricula);
        System.out.println("Marca: " + marca);
        System.out.println("Modelo: " + modelo);
        System.out.println("Año de fabricación: " + anioFabricacion);
        System.out.println("Kilometraje: " + kilometraje);
    }

    public void realizarMantenimiento() {
        System.out.println("El vehículo con matrícula " + matricula + " ha sido enviado a mantenimiento.");
        System.out.println("Costo del mantenimiento: " + calcularCostoMantenimiento());
    }
}