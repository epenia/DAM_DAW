// Subclase Camion
class Camion extends Vehiculo {
    private double capacidadCarga;

    public Camion(String matricula, String marca, String modelo, int anioFabricacion, double kilometraje, double capacidadCarga) {
        super(matricula, marca, modelo, anioFabricacion, kilometraje);
        this.capacidadCarga = capacidadCarga;
    }

    public double calcularCostoMantenimiento() {
        if (capacidadCarga < 10) {
            return (kilometraje * 0.08) + 200;
        } else {
            return (kilometraje * 0.10) + 300;
        }
    }
}