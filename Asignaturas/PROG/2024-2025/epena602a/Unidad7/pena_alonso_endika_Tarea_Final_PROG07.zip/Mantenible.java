interface Mantenible {
    void realizarMantenimiento();
}
