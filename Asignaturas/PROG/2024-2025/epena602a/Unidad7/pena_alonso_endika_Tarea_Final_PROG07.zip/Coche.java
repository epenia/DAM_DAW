class Coche extends Vehiculo {
    private String tipoCombustible;

    public Coche(String matricula, String marca, String modelo, int anioFabricacion, double kilometraje, String tipoCombustible) {
        super(matricula, marca, modelo, anioFabricacion, kilometraje);
        this.tipoCombustible = tipoCombustible;
    }

    public double calcularCostoMantenimiento() {
        if (tipoCombustible.equalsIgnoreCase("Eléctrico")) {
            return (kilometraje * 0.03) + 50;
        } else {
            return (kilometraje * 0.05) + 100;
        }
    }
}