// Programa Principal
import java.util.Scanner;

public class Principal {
    private static Vehiculo[] vehiculos = new Vehiculo[20];
    private static int contadorVehiculos = 0;
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int opcion;
        do {
            System.out.println("\nMenú:");
            System.out.println("1. Registrar vehículo");
            System.out.println("2. Realizar mantenimiento");
            System.out.println("3. Mostrar información de vehículos");
            System.out.println("4. Salir");
            System.out.println("");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    registrarVehiculo();
                    break;
                case 2:
                    realizarMantenimiento();
                    break;
                case 3:
                    mostrarInformacionVehiculos();
                    break;
                case 4:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opción no valida.");
            }
        } while (opcion != 4);
    }

    private static void registrarVehiculo() {
        if (contadorVehiculos >= 20) {
            System.out.println("No hay espacio para más vehículos.");
            return;
        }
        
        System.out.print("Ingrese matrícula: ");
        String matricula = scanner.nextLine();
        System.out.print("Ingrese marca: ");
        String marca = scanner.nextLine();
        System.out.print("Ingrese modelo: ");
        String modelo = scanner.nextLine();
        System.out.print("Ingrese año de fabricación: ");
        int anio = scanner.nextInt();
        System.out.print("Ingrese kilometraje: ");
        double kilometraje = scanner.nextDouble();
        scanner.nextLine();
        
        System.out.print("Tipo de vehículo (Coche/Moto/Camión): ");
        String tipo = scanner.nextLine();

        switch (tipo.toLowerCase()) {
            case "coche":
                String combustible;
                do {
                    System.out.print("Tipo de combustible (Gasolina/Diesel/Eléctrico): ");
                    combustible = scanner.nextLine();
                    if (!combustible.equalsIgnoreCase("Gasolina") && !combustible.equalsIgnoreCase("Diesel") && !combustible.equalsIgnoreCase("Electrico")) {
                        System.out.println("Opción inválida. Intente nuevamente.");
                    }
                } while (!combustible.equalsIgnoreCase("Gasolina") && !combustible.equalsIgnoreCase("Diesel") && !combustible.equalsIgnoreCase("Electrico"));
                
                vehiculos[contadorVehiculos++] = new Coche(matricula, marca, modelo, anio, kilometraje, combustible);
                break;
            case "moto":
                System.out.print("Cilindrada: ");
                int cilindrada = scanner.nextInt();
                vehiculos[contadorVehiculos++] = new Moto(matricula, marca, modelo, anio, kilometraje, cilindrada);
                break;
            case "camión":
                System.out.print("Capacidad de carga en toneladas: ");
                double capacidad = scanner.nextDouble();
                vehiculos[contadorVehiculos++] = new Camion(matricula, marca, modelo, anio, kilometraje, capacidad);
                break;
            default:
                System.out.println("Tipo de vehículo inválido.");
        }
    }

    private static void realizarMantenimiento() {
        System.out.print("Ingrese la matrícula del vehículo: ");
        String matricula = scanner.nextLine();
        for (Vehiculo v : vehiculos) {
            if (v != null && v.matricula.equals(matricula)) {
                v.realizarMantenimiento();
                return;
            }
        }
        System.out.println("Vehículo no encontrado.");
    }

    private static void mostrarInformacionVehiculos() {
        for (Vehiculo v : vehiculos) {
            if (v != null) {
                v.mostrarInformacion();
                System.out.println("----------------------------------");
            }
        }
    }
}
