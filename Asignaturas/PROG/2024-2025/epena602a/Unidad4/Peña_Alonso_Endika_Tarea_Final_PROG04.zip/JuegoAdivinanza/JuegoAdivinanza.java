package JuegoAdivinanza;

import java.util.Random;
import java.util.Scanner;

public class JuegoAdivinanza {
	private int numeroSecreto;
	private int intentosMaximos = 10;
	private int intentosRealizados;
	private int puntuacion = 100;
	
	
	public void iniciarJuego() {
		this.numeroSecreto = (int) (Math.random() * 100) + 1;
		int numero = 0;
		
		Scanner numeroScanner = new Scanner(System.in);
		boolean isWinner = false;

		do {
            System.out.println("Por favor, introduce un número entre 1 y 100.");
			String entrada = numeroScanner.nextLine();
			numero = this.validarEntrada(entrada);			

			if (numero == 0 || numero > 100) {
	            System.out.println("El número introducido no es válido");
	            continue;
			}
			
			if (this.numeroSecreto == numero) {
				isWinner = true;
				break;
			}						
			
			if (this.numeroSecreto > numero) {
	            System.out.println("##### El número introducido es menor que el secreto #####");
			} else {
	            System.out.println("##### El número introducido es mayor que el secreto #####");
			}
            System.out.println("");
			
			this.intentosRealizados++;
			
		} while (this.puntuacion > 0 && this.intentosRealizados < this.intentosMaximos && this.numeroSecreto != numero);
		this.calcularPuntuacion(this.intentosRealizados);
		this.mostrarMensajeFinal(isWinner);
	}
	
	public void calcularPuntuacion(int intentos) {
		this.puntuacion -= (intentos * 10);
	}
	
	public int validarEntrada(String entrada) {
		try {
	        int numero = Integer.parseInt(entrada);
	        if (numero < 1 || numero > 100) {
	            System.out.println("El número introducido no está entre el 1 y el 100");
	        }
	        
	        return numero;
	    } catch (NumberFormatException e) {
	        System.out.println("Entrada inválida. Por favor, introduce un número.");

	        return 0;
	    }
	}
	
	public void mostrarMensajeFinal(boolean ganador) {		
		if (!ganador) {
	        System.out.println("¡¡¡Usted ha perdido!!!");
			return ;
		}		

        System.out.println("¡¡¡Ha ganado!!!");
        System.out.println("Su puntuación es de: " + this.puntuacion);
	}
}
