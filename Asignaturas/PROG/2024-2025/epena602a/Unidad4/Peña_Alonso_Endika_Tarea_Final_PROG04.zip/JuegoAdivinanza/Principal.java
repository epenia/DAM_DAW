package JuegoAdivinanza;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		boolean reinicio = false;
		Scanner reiniciarJuegoScanner = new Scanner(System.in);
		
		
		do {

            System.out.println("!!! Iniciando el juego !!!");

			JuegoAdivinanza juego = new JuegoAdivinanza();
			juego.iniciarJuego();			

            System.out.println("Introduzca R para reiniciar o cualquier cosa para terminar");
			String entrada = reiniciarJuegoScanner.nextLine();
			
			if (entrada.equalsIgnoreCase("r")) {
				reinicio = true;
			}

		} while (reinicio == true);
		

        System.out.println("Gracias por jugar");
	}

}
