1.- Diseñar un documento XML bien formado que permita estructurar los vídeos de nuestra videoteca casera, suponer que la información que disponemos de cada vídeo es su título, director (nombre y apellidos por separado), productora, nacionalidad, año de estreno y tipo (comedia, drama, thriller, animación, documental, etc.), además deberemos inventarnos un código para cada uno. Rellenar la ficha de al menos tres vídeos, uno de ellos tendrá como mínimo dos productoras.

 

La valoración de este ejercicio será de un total de 3 puntos.

Tiempo de resolución aproximado: 2 h.

 

2.- Diseñar un documento XML bien formado que permita estructurar la información para permitir la gestión informática de los pasajeros de un vuelo, sabiendo que tiene un código que nos inventaremos, aeropuerto de origen, aeropuerto de destino, fecha y hora. Por el momento hay tres pasajeros con reserva:

 

- Luisa Santos García con nif 12345678H, teléfono 666123456, email lsgarcia@gmail.com. Vuela de Madrid a Barcelona el 21 de septiembre de 2024 a las 10:40.
- María Fernández Gutiérrez con nif 16965696L, teléfono 789654321, email maria.fdezgtrrez@hotmail.com. No hay información sobre el vuelo.
- José Grillo Ramos con nif 98765432H, teléfono 656566555, email jgrillor@gmail.com. Vuela de Bilbao a Málaga.


La valoración de este ejercicio será de un total de 3 puntos.

Tiempo de resolución aproximado: 2 h.

 

3.- Diseñar un documento bien formado en XML que permita estructurar la información de las recetas de cocina que me enseñó mi abuela. Hay que hacerlo de modo que un sistema informático pueda realizar búsquedas por ingredientes, cantidad de comensales o nombre de la receta. Aplicarlo a la siguiente receta de cocina:

 

Tortilla de patata (4 personas)
Ingredientes:

1/2 Kg. de cebollas.
1 Kg de patatas.
6 huevos.
1/2 litros de aceite de oliva.
Sal.

Proceso:

1.- Lavar, pelar y partir las cebollas en rodajas finas. 
2.- Lavar, pelar y partir las patatas en rodajas finas.
3.- Poner las patatas y la cebolla en una sartén y cubrir de aceite.
4.- Ponerlo a fuego medio hasta que se doren las patatas.
5.- Batir los huevos y echarles la patatas y la cebolla, salarlo.
6.- Poner la mezcla en la sartén y ayudándose de un plato darle la vuelta cuando esté dorada.

 

La valoración de este ejercicio será de un total de 4 puntos.

Tiempo de resolución aproximado: 3 h.