#!/bin/bash
myPassword='EstoContrasenia'

validar_entrada(){
local password 
}

pista(){
local longitudTexto=${#myPassword}
local pista=$((0+$RANDOM % $longitudTexto-1))
local mostrarPista=""

for (( i=0; i$longitudText; i++)); do
if [ pista -eq $i ];then
mostrarPista+="${myPassword:$i:1}"
else
mostrarPista+='*'
fi
done

}


intentos=0

while true; do
	if [ $intentos -eq 3 ];then
	 	echo "Has llegado al limite de intentos saliendo ..."
	 	break
	fi
	
	echo "============== MENÚ =============="
	echo "ayuda: muestra una pista"
	echo "salir: sale del programa"
	echo ""	
	echo "cualquier otracosa se compara con la contraseña"
	echo "=================================="
	
	read -p "Averigua la contraseña: " input
	
	case $input in
	 ayuda)
	 	pista
	 	;;	
	 salir)
	 	echo "Saliendo del programa"
	 	break
	 	;;
	 *)
	 	validar_entrada $input
	 	;;
 	esac
 	((intentos++))
done
